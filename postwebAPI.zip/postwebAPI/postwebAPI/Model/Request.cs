﻿namespace postwebAPI.Model
{
    public class Request
    {
        public string Operand { get; set; }
        public List<double> Numbers { get; set; }

    }
}
